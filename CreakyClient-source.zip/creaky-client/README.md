# Creaky Client (Minecraft Java 1.21.1 · Fabric)

All-in-one PvP + performance client, shipped as a Fabric mod + modpack.
Open the menu in-game with **Right Shift** (rebindable). Zoom = hold **C**.

## Features
- **HUD:** FPS, CPS (L|R), ping, coordinates, keystrokes, armor & durability viewer, potion effects
- **PvP:** Crystal Optimizer, Zoom, Toggle Sprint, Low Shield, Low Totem, No Hit Cam
- **Visual:** Fullbright, Low Fire, Creaky Cape (3 styles, local only)
- **Performance:** one-click Boost preset (auto-applied on first launch), entity distance culling,
  plus a bundled modpack script (Lithium, FerriteCore, ModernFix, EntityCulling; optional Sodium, ImmediatelyFast)

## Build (no PC needed)
1. Create a GitHub repo and upload this whole folder.
2. Open the **Actions** tab → *Build Creaky Client* (runs on every push).
3. Download the artifact `CreakyClient-pack.zip`.
4. Extract it. Copy everything in `mods/` into your instance's `mods` folder
   (Fabric Loader 0.16+ for 1.21.1 must be installed in your launcher).
5. `mods-optional/` = Sodium + ImmediatelyFast. Try them; if the game crashes on launch, remove them.

Local build: install JDK 21 + Gradle 8.10, then `gradle build` → `build/libs/creaky-client-1.0.0.jar`.

## Notes
- Cape is client-side: only you see it. Showing it to others needs a cape server.
- Ping can't be "boosted" by a client; it is only displayed.
- Crystal Optimizer / Fullbright / Zoom etc. are banned on some servers: every feature has an on/off toggle (Crystal Optimizer is off by default).
- Recommended JVM args (if your launcher allows): `-XX:+UseG1GC -XX:MaxGCPauseMillis=50 -Xmx2G`
- Regenerate textures: `python3 tools/gen_assets.py`
