package dev.creaky.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

/** One-click performance preset (safe, vanilla options only). */
public final class Boost {
    public static void apply(MinecraftClient mc) {
        GameOptions o = mc.options;
        o.getViewDistance().setValue(8);
        o.getSimulationDistance().setValue(6);
        o.getEntityDistanceScaling().setValue(0.75);
        o.getParticles().setValue(ParticlesMode.DECREASED);
        o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        o.getGraphicsMode().setValue(GraphicsMode.FAST);
        o.getAo().setValue(false);
        o.getEntityShadows().setValue(false);
        o.getBiomeBlendRadius().setValue(1);
        o.getEnableVsync().setValue(false);
        o.getMaxFps().setValue(260);
        o.write();
    }
    private Boost() {}
}
