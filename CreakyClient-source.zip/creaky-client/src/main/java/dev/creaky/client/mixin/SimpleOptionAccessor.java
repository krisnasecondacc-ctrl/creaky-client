package dev.creaky.client.mixin;

import net.minecraft.client.option.SimpleOption;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(SimpleOption.class)
public interface SimpleOptionAccessor<T> {
    /** Sets the value without range validation (used for Fullbright gamma). */
    @Accessor("value")
    void creaky_setValue(T value);
}
