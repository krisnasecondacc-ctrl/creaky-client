package dev.creaky.client.mixin;

import dev.creaky.client.config.Features;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameOverlayRenderer.class)
public class InGameOverlayRendererMixin {
    @Unique private static boolean creaky$pushed;

    @Inject(method = "renderFireOverlay", at = @At("HEAD"))
    private static void creaky$fireHead(MinecraftClient client, MatrixStack matrices, CallbackInfo ci) {
        creaky$pushed = Features.LOW_FIRE.isOn();
        if (creaky$pushed) {
            matrices.push();
            matrices.translate(0.0, -0.3, 0.0);
        }
    }

    @Inject(method = "renderFireOverlay", at = @At("RETURN"))
    private static void creaky$fireTail(MinecraftClient client, MatrixStack matrices, CallbackInfo ci) {
        if (creaky$pushed) {
            matrices.pop();
            creaky$pushed = false;
        }
    }
}
