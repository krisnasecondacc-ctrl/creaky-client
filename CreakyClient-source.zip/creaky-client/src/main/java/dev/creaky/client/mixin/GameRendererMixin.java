package dev.creaky.client.mixin;

import dev.creaky.client.CreakyClient;
import dev.creaky.client.config.CreakyConfig;
import dev.creaky.client.config.Features;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
    private void creaky$noHurtCam(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        if (Features.NO_HURTCAM.isOn()) ci.cancel();
    }

    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void creaky$zoom(Camera camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Double> cir) {
        if (CreakyClient.zooming) cir.setReturnValue(cir.getReturnValue() / CreakyConfig.INSTANCE.zoomFactor);
    }
}
