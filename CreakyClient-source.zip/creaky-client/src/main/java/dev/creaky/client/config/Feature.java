package dev.creaky.client.config;

public final class Feature {
    public final String id, name;
    public final Category category;
    public final boolean defaultOn;
    private boolean on;

    Feature(String id, String name, Category category, boolean defaultOn) {
        this.id = id; this.name = name; this.category = category; this.defaultOn = defaultOn; this.on = defaultOn;
    }
    public boolean isOn() { return on; }
    public void setOn(boolean v) { on = v; }
    public void toggle() { on = !on; }
}
