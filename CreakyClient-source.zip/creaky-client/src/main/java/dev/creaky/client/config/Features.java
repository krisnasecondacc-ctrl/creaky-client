package dev.creaky.client.config;

import java.util.ArrayList;
import java.util.List;

public final class Features {
    public static final List<Feature> ALL = new ArrayList<>();

    // HUD
    public static final Feature FPS        = reg("fps", "FPS Counter", Category.HUD, true);
    public static final Feature CPS        = reg("cps", "CPS Counter", Category.HUD, true);
    public static final Feature PING       = reg("ping", "Ping Display", Category.HUD, true);
    public static final Feature COORDS     = reg("coords", "Coordinates", Category.HUD, true);
    public static final Feature KEYSTROKES = reg("keystrokes", "Keystrokes", Category.HUD, true);
    public static final Feature ARMOR      = reg("armor", "Armor & Durability", Category.HUD, true);
    public static final Feature POTIONS    = reg("potions", "Potion Effects", Category.HUD, true);

    // PvP
    public static final Feature CRYSTAL    = reg("crystal", "Crystal Optimizer", Category.PVP, false);
    public static final Feature ZOOM       = reg("zoom", "Zoom (hold C)", Category.PVP, true);
    public static final Feature AUTOSPRINT = reg("autosprint", "Toggle Sprint", Category.PVP, false);
    public static final Feature LOW_SHIELD = reg("lowshield", "Low Shield", Category.PVP, true);
    public static final Feature LOW_TOTEM  = reg("lowtotem", "Low Totem", Category.PVP, true);
    public static final Feature NO_HURTCAM = reg("nohurtcam", "No Hit Cam", Category.PVP, true);

    // Visual
    public static final Feature FULLBRIGHT = reg("fullbright", "Fullbright", Category.VISUAL, false);
    public static final Feature LOW_FIRE   = reg("lowfire", "Low Fire", Category.VISUAL, true);
    public static final Feature CAPE       = reg("cape", "Creaky Cape", Category.VISUAL, true);

    // Performance
    public static final Feature CULLING    = reg("culling", "Entity Distance Cull", Category.PERF, true);

    private static Feature reg(String id, String name, Category c, boolean def) {
        Feature f = new Feature(id, name, c, def);
        ALL.add(f);
        return f;
    }

    public static List<Feature> of(Category c) {
        return ALL.stream().filter(f -> f.category == c).toList();
    }
    private Features() {}
}
