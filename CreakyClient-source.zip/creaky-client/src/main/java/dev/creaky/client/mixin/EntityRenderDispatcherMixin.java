package dev.creaky.client.mixin;

import dev.creaky.client.config.CreakyConfig;
import dev.creaky.client.config.Features;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderDispatcher.class)
public class EntityRenderDispatcherMixin {
    /** Skips rendering of far-away non-player entities (big FPS win in crowded areas). */
    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private <E extends Entity> void creaky$cull(E entity, Frustum frustum, double x, double y, double z,
                                                CallbackInfoReturnable<Boolean> cir) {
        if (!Features.CULLING.isOn() || entity instanceof PlayerEntity || entity instanceof EndCrystalEntity) return;
        double dx = entity.getX() - x, dy = entity.getY() - y, dz = entity.getZ() - z;
        double max = CreakyConfig.INSTANCE.cullDistance;
        if (dx * dx + dy * dy + dz * dz > max * max) cir.setReturnValue(false);
    }
}
