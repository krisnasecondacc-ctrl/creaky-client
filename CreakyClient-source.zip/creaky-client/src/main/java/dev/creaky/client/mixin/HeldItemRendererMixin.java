package dev.creaky.client.mixin;

import dev.creaky.client.config.Features;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
    @Unique private boolean creaky$pushed;

    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
    private void creaky$head(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                             float swingProgress, ItemStack item, float equipProgress, MatrixStack matrices,
                             VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        creaky$pushed = false;
        if (Features.LOW_SHIELD.isOn() && item.isOf(Items.SHIELD)) {
            matrices.push();
            matrices.translate(0.0, -0.2, 0.0);
            creaky$pushed = true;
        } else if (Features.LOW_TOTEM.isOn() && item.isOf(Items.TOTEM_OF_UNDYING)) {
            matrices.push();
            matrices.translate(0.0, -0.3, 0.0);
            matrices.scale(0.75f, 0.75f, 0.75f);
            creaky$pushed = true;
        }
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"))
    private void creaky$tail(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                             float swingProgress, ItemStack item, float equipProgress, MatrixStack matrices,
                             VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        if (creaky$pushed) {
            matrices.pop();
            creaky$pushed = false;
        }
    }
}
