package dev.creaky.client.gui;

import dev.creaky.client.CreakyClient;
import dev.creaky.client.config.Category;
import dev.creaky.client.config.CreakyConfig;
import dev.creaky.client.config.Feature;
import dev.creaky.client.config.Features;
import dev.creaky.client.util.Boost;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.List;

public class CreakyScreen extends Screen {
    private static final int[] CULL = { 24, 32, 48, 64, 96, 128 };
    private static final double[] ZOOM = { 2, 3, 4, 6, 8 };

    private final Screen parent;
    private Category tab = Category.HUD;

    public CreakyScreen(Screen parent) {
        super(Text.literal("Creaky Client"));
        this.parent = parent;
    }

    private static Text label(Feature f) {
        return Text.literal(f.name + ": " + (f.isOn() ? "§aON" : "§cOFF"));
    }

    @Override
    protected void init() {
        int cx = width / 2;
        Category[] cs = Category.values();
        int tw = 72, gap = 4;
        int sx = cx - (cs.length * tw + (cs.length - 1) * gap) / 2;
        for (int i = 0; i < cs.length; i++) {
            final Category c = cs[i];
            ButtonWidget b = ButtonWidget.builder(Text.literal(c.label), btn -> { tab = c; clearAndInit(); })
                    .dimensions(sx + i * (tw + gap), 28, tw, 20).build();
            b.active = c != tab;
            addDrawableChild(b);
        }

        List<Feature> list = Features.of(tab);
        int y0 = 58;
        for (int i = 0; i < list.size(); i++) {
            Feature f = list.get(i);
            int x = cx - 155 + (i % 2) * 158;
            int y = y0 + (i / 2) * 24;
            addDrawableChild(ButtonWidget.builder(label(f), btn -> { f.toggle(); btn.setMessage(label(f)); })
                    .dimensions(x, y, 152, 20).build());
        }

        int ey = y0 + ((list.size() + 1) / 2) * 24 + 6;
        CreakyConfig cfg = CreakyConfig.INSTANCE;
        switch (tab) {
            case VISUAL -> addDrawableChild(ButtonWidget.builder(
                    Text.literal("Cape style: " + CreakyClient.CAPE_NAMES[cfg.capeIndex % 3]), btn -> {
                        cfg.capeIndex = (cfg.capeIndex + 1) % CreakyClient.CAPE_NAMES.length;
                        btn.setMessage(Text.literal("Cape style: " + CreakyClient.CAPE_NAMES[cfg.capeIndex]));
                    }).dimensions(cx - 76, ey, 152, 20).build());
            case PVP -> addDrawableChild(ButtonWidget.builder(
                    Text.literal("Zoom level: " + cfg.zoomFactor + "x"), btn -> {
                        int idx = 0;
                        for (int i = 0; i < ZOOM.length; i++) if (ZOOM[i] == cfg.zoomFactor) idx = i;
                        cfg.zoomFactor = ZOOM[(idx + 1) % ZOOM.length];
                        btn.setMessage(Text.literal("Zoom level: " + cfg.zoomFactor + "x"));
                    }).dimensions(cx - 76, ey, 152, 20).build());
            case PERF -> {
                addDrawableChild(ButtonWidget.builder(Text.literal("Apply Boost preset"), btn -> {
                    Boost.apply(client);
                    btn.setMessage(Text.literal("Boost applied ✓"));
                }).dimensions(cx - 155, ey, 152, 20).build());
                addDrawableChild(ButtonWidget.builder(Text.literal("Cull distance: " + cfg.cullDistance), btn -> {
                    int idx = 0;
                    for (int i = 0; i < CULL.length; i++) if (CULL[i] == cfg.cullDistance) idx = i;
                    cfg.cullDistance = CULL[(idx + 1) % CULL.length];
                    btn.setMessage(Text.literal("Cull distance: " + cfg.cullDistance));
                }).dimensions(cx + 3, ey, 152, 20).build());
            }
            default -> { }
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(cx - 60, height - 28, 120, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        String title = "Creaky Client";
        int tx = width / 2 - textRenderer.getWidth(title) / 2;
        ctx.drawTexture(CreakyClient.LOGO, tx - 20, 5, 16, 16, 0f, 0f, 64, 64, 64, 64);
        ctx.drawTextWithShadow(textRenderer, title, tx, 9, 0xFFFF8A2A);
    }

    @Override
    public void close() {
        CreakyConfig.save();
        client.setScreen(parent);
    }
}
