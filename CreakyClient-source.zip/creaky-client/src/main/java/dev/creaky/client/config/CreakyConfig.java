package dev.creaky.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.creaky.client.CreakyClient;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

public final class CreakyConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("creakyclient.json");

    public static CreakyConfig INSTANCE = new CreakyConfig();

    public Map<String, Boolean> modules = new LinkedHashMap<>();
    public int cullDistance = 48;
    public double zoomFactor = 4.0;
    public int capeIndex = 0;
    public boolean boosted = false;

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                try (Reader r = Files.newBufferedReader(FILE)) {
                    CreakyConfig c = GSON.fromJson(r, CreakyConfig.class);
                    if (c != null) INSTANCE = c;
                }
            }
        } catch (Exception e) {
            CreakyClient.LOG.warn("Could not read config, using defaults", e);
        }
        if (INSTANCE.modules == null) INSTANCE.modules = new LinkedHashMap<>();
        for (Feature f : Features.ALL) {
            Boolean b = INSTANCE.modules.get(f.id);
            f.setOn(b != null ? b : f.defaultOn);
        }
    }

    public static void save() {
        INSTANCE.modules.clear();
        for (Feature f : Features.ALL) INSTANCE.modules.put(f.id, f.isOn());
        try (Writer w = Files.newBufferedWriter(FILE)) {
            GSON.toJson(INSTANCE, w);
        } catch (Exception e) {
            CreakyClient.LOG.warn("Could not save config", e);
        }
    }
    private CreakyConfig() {}
}
