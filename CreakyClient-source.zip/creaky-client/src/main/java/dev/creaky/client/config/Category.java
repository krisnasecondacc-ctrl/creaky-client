package dev.creaky.client.config;

public enum Category {
    HUD("HUD"), PVP("PvP"), VISUAL("Visual"), PERF("Performance");
    public final String label;
    Category(String label) { this.label = label; }
}
