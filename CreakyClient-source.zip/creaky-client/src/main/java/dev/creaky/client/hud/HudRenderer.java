package dev.creaky.client.hud;

import dev.creaky.client.config.Features;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;

import java.util.List;

public final class HudRenderer {
    private static final int ACCENT = 0xFFFF8A2A;

    public static void render(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden || mc.getDebugHud().shouldShowDebugHud()) return;
        TextRenderer tr = mc.textRenderer;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();

        int y = 4;
        if (Features.FPS.isOn())    { ctx.drawTextWithShadow(tr, "FPS: " + mc.getCurrentFps(), 4, y, ACCENT); y += 11; }
        if (Features.CPS.isOn())    { ctx.drawTextWithShadow(tr, "CPS: " + CpsTracker.left() + " | " + CpsTracker.right(), 4, y, ACCENT); y += 11; }
        if (Features.PING.isOn())   { ctx.drawTextWithShadow(tr, "Ping: " + ping(mc) + " ms", 4, y, ACCENT); y += 11; }
        if (Features.COORDS.isOn()) {
            ctx.drawTextWithShadow(tr, String.format("XYZ: %.1f %.1f %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ()), 4, y, 0xFFFFFFFF); y += 11;
            ctx.drawTextWithShadow(tr, "Facing: " + mc.player.getHorizontalFacing().asString(), 4, y, 0xFFFFFFFF);
        }

        if (Features.KEYSTROKES.isOn()) keystrokes(ctx, tr, mc, 6, h / 2 - 10);
        if (Features.ARMOR.isOn())      armor(ctx, tr, mc, w - 72, h / 2 - 50);
        if (Features.POTIONS.isOn())    potions(ctx, tr, mc, w);
    }

    private static int ping(MinecraftClient mc) {
        if (mc.getNetworkHandler() == null || mc.player == null) return 0;
        PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        return e == null ? 0 : e.getLatency();
    }

    private static void key(DrawContext ctx, TextRenderer tr, int x, int y, int w, int hgt, String label, boolean down) {
        ctx.fill(x, y, x + w, y + hgt, down ? 0xAAFFFFFF : 0x80000000);
        ctx.drawCenteredTextWithShadow(tr, label, x + w / 2, y + (hgt - 8) / 2, down ? 0xFF000000 : 0xFFFFFFFF);
    }

    private static void keystrokes(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int x, int y) {
        var o = mc.options;
        key(ctx, tr, x + 22, y, 20, 20, "W", o.forwardKey.isPressed());
        key(ctx, tr, x, y + 22, 20, 20, "A", o.leftKey.isPressed());
        key(ctx, tr, x + 22, y + 22, 20, 20, "S", o.backKey.isPressed());
        key(ctx, tr, x + 44, y + 22, 20, 20, "D", o.rightKey.isPressed());
        key(ctx, tr, x, y + 44, 31, 20, "L " + CpsTracker.left(), o.attackKey.isPressed());
        key(ctx, tr, x + 33, y + 44, 31, 20, "R " + CpsTracker.right(), o.useKey.isPressed());
        key(ctx, tr, x, y + 66, 64, 10, "---", o.jumpKey.isPressed());
    }

    private static void armor(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int x, int y) {
        var inv = mc.player.getInventory();
        ItemStack[] stacks = { inv.armor.get(3), inv.armor.get(2), inv.armor.get(1), inv.armor.get(0),
                mc.player.getMainHandStack(), mc.player.getOffHandStack() };
        for (ItemStack s : stacks) {
            if (s.isEmpty()) continue;
            ctx.drawItem(s, x, y);
            ctx.drawItemInSlot(tr, s, x, y);
            if (s.isDamageable()) {
                int left = s.getMaxDamage() - s.getDamage();
                float ratio = (float) left / s.getMaxDamage();
                int col = ratio > 0.5f ? 0xFF55FF55 : ratio > 0.2f ? 0xFFFFFF55 : 0xFFFF5555;
                ctx.drawTextWithShadow(tr, left + "/" + s.getMaxDamage(), x + 20, y + 4, col);
            }
            y += 18;
        }
    }

    private static void potions(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int w) {
        int y = 4;
        for (StatusEffectInstance e : mc.player.getStatusEffects()) {
            String time = e.isInfinite() ? "∞" : String.format("%d:%02d", e.getDuration() / 1200, (e.getDuration() / 20) % 60);
            Text name = e.getEffectType().value().getName();
            String line = name.getString() + " " + (e.getAmplifier() + 1) + "  " + time;
            ctx.drawTextWithShadow(tr, line, w - tr.getWidth(line) - 4, y, 0xFFFFFFFF);
            y += 11;
        }
    }
    private HudRenderer() {}
}
