package dev.creaky.client;

import dev.creaky.client.config.CreakyConfig;
import dev.creaky.client.config.Features;
import dev.creaky.client.gui.CreakyScreen;
import dev.creaky.client.hud.HudRenderer;
import dev.creaky.client.mixin.SimpleOptionAccessor;
import dev.creaky.client.util.Boost;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CreakyClient implements ClientModInitializer {
    public static final String ID = "creakyclient";
    public static final Logger LOG = LoggerFactory.getLogger("CreakyClient");
    public static final Identifier LOGO = Identifier.of(ID, "textures/gui/logo.png");
    public static final String[] CAPE_NAMES = { "Creaky", "Ember", "Frost" };
    public static final Identifier[] CAPES = {
            Identifier.of(ID, "textures/cape/creaky.png"),
            Identifier.of(ID, "textures/cape/ember.png"),
            Identifier.of(ID, "textures/cape/frost.png") };

    public static KeyBinding menuKey, zoomKey;
    public static boolean zooming;
    private static Double savedGamma;

    @Override
    public void onInitializeClient() {
        CreakyConfig.load();
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.creakyclient.menu",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.creakyclient"));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.creakyclient.zoom",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "category.creakyclient"));

        ClientTickEvents.END_CLIENT_TICK.register(CreakyClient::tick);
        HudRenderCallback.EVENT.register(HudRenderer::render);

        // Crystal Optimizer: remove the crystal client-side the instant it is hit.
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient && Features.CRYSTAL.isOn() && entity instanceof EndCrystalEntity) {
                MinecraftClient.getInstance().send(() -> {
                    if (!entity.isRemoved()) entity.remove(Entity.RemovalReason.KILLED);
                });
            }
            return ActionResult.PASS;
        });

        // Title screen branding
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof TitleScreen) {
                ScreenEvents.afterRender(screen).register((s, ctx, mx, my, delta) -> {
                    ctx.drawTexture(LOGO, 6, 6, 32, 32, 0f, 0f, 64, 64, 64, 64);
                    ctx.drawTextWithShadow(client.textRenderer, "Creaky Client", 42, 12, 0xFFFF8A2A);
                    ctx.drawTextWithShadow(client.textRenderer, "Right Shift = menu", 42, 24, 0xFFAAAAAA);
                });
            }
        });
        LOG.info("Creaky Client loaded");
    }

    @SuppressWarnings("unchecked")
    private static void tick(MinecraftClient mc) {
        if (mc.options == null) return;

        // First launch: apply performance preset once.
        if (!CreakyConfig.INSTANCE.boosted) {
            Boost.apply(mc);
            CreakyConfig.INSTANCE.boosted = true;
            CreakyConfig.save();
        }

        while (menuKey.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new CreakyScreen(null));
        }
        zooming = Features.ZOOM.isOn() && zoomKey.isPressed();

        // Fullbright via gamma
        var gamma = mc.options.getGamma();
        if (Features.FULLBRIGHT.isOn()) {
            if (savedGamma == null) {
                double cur = gamma.getValue();
                savedGamma = cur > 1.0 ? 0.5 : cur;
            }
            ((SimpleOptionAccessor<Double>) (Object) gamma).creaky_setValue(16.0);
        } else if (savedGamma != null) {
            gamma.setValue(savedGamma);
            savedGamma = null;
        }

        // Toggle sprint
        if (mc.player != null && Features.AUTOSPRINT.isOn() && mc.options.forwardKey.isPressed()
                && !mc.player.isSneaking() && !mc.player.horizontalCollision
                && mc.player.getHungerManager().getFoodLevel() > 6) {
            mc.player.setSprinting(true);
        }
    }
}
