package dev.creaky.client.mixin;

import dev.creaky.client.CreakyClient;
import dev.creaky.client.config.CreakyConfig;
import dev.creaky.client.config.Features;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayerEntity.class)
public abstract class AbstractClientPlayerEntityMixin {
    /** Local cape (visible to you only) + matching elytra texture. */
    @Inject(method = "getSkinTextures", at = @At("RETURN"), cancellable = true)
    private void creaky$cape(CallbackInfoReturnable<SkinTextures> cir) {
        if (!Features.CAPE.isOn()) return;
        if ((Object) this != MinecraftClient.getInstance().player) return;
        SkinTextures o = cir.getReturnValue();
        int i = Math.floorMod(CreakyConfig.INSTANCE.capeIndex, CreakyClient.CAPES.length);
        Identifier cape = CreakyClient.CAPES[i];
        cir.setReturnValue(new SkinTextures(o.texture(), o.textureUrl(), cape, cape, o.model(), o.secure()));
    }
}
