import zlib, struct, os
OUT = os.path.join(os.path.dirname(__file__), "..", "src/main/resources/assets/creakyclient")
def png(path, w, h, px):
    raw = b"".join(b"\x00" + b"".join(bytes(px[y][x]) for x in range(w)) for y in range(h))
    def ch(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    data = b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)) + ch(b"IDAT", zlib.compress(raw, 9)) + ch(b"IEND", b"")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "wb").write(data)

HEAD = [
"................",
"...dddddddddd...",
"..dbbllbbbblbbd.",
".dbbbbbddbbbbbbd",
"dbblbbbddbbbblbd",
"dbkkkkkbbkkkkkbd",
"dbkooyybbyyookbd",
"dbkkkkkbbkkkkkbd",
"dbbbbbbddbbbbbbd",
"dbbllbbddbbbllbd",
"dbbbbkkkkkkbbbbd",
"dbbbkdkdkdkdkbbd",
".dbbbkkkkkkbbbd.",
"..ddbbbbbbbbdd..",
"....dddddddd....",
"................"]
PAL = {"d": (46,42,39,255), "b": (74,69,64,255), "l": (107,100,92,255),
       "k": (18,16,15,255), "o": (255,122,26,255), "y": (255,190,80,255), ".": (0,0,0,0)}
def head(scale):
    n = 16 * scale
    return [[PAL[HEAD[y // scale][x // scale]] for x in range(n)] for y in range(n)]
png(OUT + "/textures/gui/logo.png", 64, 64, head(4))
png(OUT + "/icon.png", 128, 128, head(8))

CAPES = {"creaky": ((74,69,64), (46,42,39), (255,122,26)),
         "ember":  ((92,30,24), (50,14,12), (255,200,60)),
         "frost":  ((58,76,92), (30,42,54), (120,230,255))}
for name, (base, dark, glow) in CAPES.items():
    px = [[(0,0,0,0)] * 64 for _ in range(32)]
    for y in range(32):
        for x in range(64):
            shade = dark if (x % 3 == 0 or (x * 7 + y * 3) % 11 == 0) else base
            px[y][x] = (*shade, 255)
    for (x0, y0) in ((3, 5), (7, 5)):          # glowing eyes on the cape back
        for dx in range(2):
            for dy in range(2):
                px[y0 + dy][x0 + dx] = (*glow, 255)
    png(OUT + f"/textures/cape/{name}.png", 64, 32, px)
print("assets ok")
