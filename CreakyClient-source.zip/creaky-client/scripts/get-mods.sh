#!/usr/bin/env bash
# Downloads performance mods (Fabric, MC 1.21.1) from Modrinth.
# Usage: bash scripts/get-mods.sh [output_dir]     (needs curl + jq)
set -euo pipefail
MC="1.21.1"
OUT="${1:-pack}"
UA="CreakyClient/1.0 (modpack builder)"
mkdir -p "$OUT/mods" "$OUT/mods-optional"

fetch() {  # fetch <modrinth-slug> <target-dir>
  local slug="$1" dir="$2" url
  url=$(curl -fsSL -A "$UA" -G "https://api.modrinth.com/v2/project/$slug/version" \
        --data-urlencode "game_versions=[\"$MC\"]" --data-urlencode 'loaders=["fabric"]' \
        | jq -r '.[0].files | (map(select(.primary))[0] // .[0]).url')
  if [ -z "$url" ] || [ "$url" = "null" ]; then echo "!! no $MC build for $slug, skipping"; return; fi
  echo "-> $slug"
  curl -fsSL -A "$UA" -o "$dir/$(basename "$url")" "$url"
}

# Safe on almost every setup
for m in fabric-api lithium ferrite-core modernfix entityculling; do fetch "$m" "$OUT/mods"; done
# Big FPS gains, but need a compatible OpenGL renderer (may crash on some Android renderers)
for m in sodium immediatelyfast; do fetch "$m" "$OUT/mods-optional"; done
echo "Done. Copy $OUT/mods/* (and optionally $OUT/mods-optional/*) into your instance's mods folder."
